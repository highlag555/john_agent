# Setup Guide — Telegram ↔ Claude Agent

## What This Does
A lightweight Python server that runs 24/7 on Railway (~$5/month).
- You send text or voice notes on Telegram
- Voice notes are transcribed via Whisper
- Claude responds as your autonomous agent with memory + soul file
- Scheduled tasks run automatically (nightly loop at 2 AM, morning digest at 8 AM)

---

## Step 1 — Create Your Telegram Bot

1. Open Telegram → search **@BotFather**
2. Send `/newbot`
3. Follow prompts → save your **Bot Token** (looks like `7123456789:AAFabc...`)

## Step 2 — Find Your Telegram User ID

1. Message **@userinfobot** on Telegram
2. It replies with your numeric ID (e.g. `123456789`)
3. Save this — it's your `TELEGRAM_ALLOWED_USER_ID`

## Step 3 — Deploy to Railway

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Push this folder to a GitHub repo, connect it
3. Add these environment variables in Railway dashboard:

```
TELEGRAM_BOT_TOKEN       = (from BotFather)
TELEGRAM_ALLOWED_USER_ID = (from @userinfobot)
ANTHROPIC_API_KEY        = sk-ant-...
OPENAI_API_KEY           = sk-...        (optional, for voice notes)
TELEGRAM_WEBHOOK_SECRET  = pick_any_secret_string
```

4. Deploy. Railway gives you a public URL like `https://your-app.railway.app`

## Step 4 — Register the Webhook

Run this once to tell Telegram where to send messages:

```bash
python main.py --register-webhook https://your-app.railway.app
```

Or just hit this URL in your browser:
```
https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook?url=https://your-app.railway.app/webhook
```

## Step 5 — Test It

1. Open Telegram → find your bot → send `/start`
2. It should reply with the welcome message
3. Send a text message or voice note
4. Watch it respond as your agent

---

## Commands

| Command | What it does |
|---------|-------------|
| `/start` | Welcome message + command list |
| `/status` | Current open tasks and revenue |
| `/memory` | Summary of memory files |
| `/loop` | Run the nightly self-improvement loop right now |
| `/clear` | Clear conversation history |

---

## Customising the Soul File

Edit `soul_file.txt` to change your agent's identity, mission, and operating principles.
The file is loaded fresh on every message — no restart needed.

---

## Memory Structure

```
memory/
  daily/          ← One file per day, logs all activity
  life/           ← Long-term knowledge (customers, products, market)
  tacit/
    security.md   ← Trusted vs untrusted channel rules
    patterns.md   ← Lessons learned (updated nightly)
```

---

## Upgrading to More Power

Once the basic setup is running, add these env vars to unlock more tools:

| Env Var | What it enables |
|---------|-----------------|
| `STRIPE_SECRET_KEY` | Agent can create/check Stripe products and revenue |
| `GITHUB_TOKEN` | Agent can push code and manage repos |
| `VERCEL_TOKEN` | Agent can deploy sites |
| `RESEND_API_KEY` | Agent can send emails |

Add a `tools.py` module to wire these up as callable functions Claude can invoke.
