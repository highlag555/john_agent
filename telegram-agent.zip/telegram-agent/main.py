"""
Telegram ↔ Claude Agent Server
Receives Telegram messages/voice notes → runs through Claude with Soul File → replies
Deploy on Railway, Fly.io, or any always-on host.
"""

import os
import json
from dotenv import load_dotenv
load_dotenv()
import asyncio
import logging
import datetime
import httpx
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
import anthropic
from apscheduler.schedulers.asyncio import AsyncIOScheduler

# ─── CONFIG ───────────────────────────────────────────────────────────────────

TELEGRAM_BOT_TOKEN   = os.environ["TELEGRAM_BOT_TOKEN"]
TELEGRAM_WEBHOOK_SECRET = os.environ.get("TELEGRAM_WEBHOOK_SECRET", "")
ALLOWED_USER_ID      = int(os.environ["TELEGRAM_ALLOWED_USER_ID"])  # your Telegram user ID
ANTHROPIC_API_KEY    = os.environ["ANTHROPIC_API_KEY"]
OPENAI_API_KEY       = os.environ.get("OPENAI_API_KEY", "")         # for Whisper transcription

CLAUDE_MODEL         = "claude-sonnet-4-5"  # upgrade to claude-opus-4-5 for harder tasks
MAX_CONTEXT_MESSAGES = 40   # messages kept in rolling context
MEMORY_DIR           = Path("memory")
SOUL_FILE_PATH       = Path("soul_file.txt")

TELEGRAM_API         = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

# ─── MEMORY ───────────────────────────────────────────────────────────────────

def load_soul_file() -> str:
    if SOUL_FILE_PATH.exists():
        return SOUL_FILE_PATH.read_text()
    return "You are an autonomous AI agent. Be helpful, direct, and action-oriented."


def today_note_path() -> Path:
    date_str = datetime.date.today().isoformat()
    path = MEMORY_DIR / "daily" / f"{date_str}.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def load_today_context() -> str:
    path = today_note_path()
    if path.exists():
        return f"\n\n## Today's Context ({path.name})\n{path.read_text()}"
    return ""


def load_patterns() -> str:
    path = MEMORY_DIR / "tacit" / "patterns.md"
    if path.exists():
        content = path.read_text().strip()
        if content:
            return f"\n\n## Operational Patterns\n{content}"
    return ""


def build_system_prompt() -> str:
    soul = load_soul_file()
    context = load_today_context()
    patterns = load_patterns()
    return soul + context + patterns


def save_to_daily_note(entry: str):
    path = today_note_path()
    timestamp = datetime.datetime.now().strftime("%H:%M")
    with open(path, "a") as f:
        f.write(f"\n### {timestamp}\n{entry}\n")


# ─── CONVERSATION STATE ───────────────────────────────────────────────────────
# Simple in-memory rolling context. For persistence across restarts, swap with SQLite.

conversation_history: list[dict] = []


def add_to_history(role: str, content: str):
    conversation_history.append({"role": role, "content": content})
    # Keep rolling window
    if len(conversation_history) > MAX_CONTEXT_MESSAGES:
        conversation_history.pop(0)


# ─── CLAUDE ───────────────────────────────────────────────────────────────────

async def ask_claude(user_message: str) -> str:
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    add_to_history("user", user_message)

    system_prompt = build_system_prompt()

    try:
        response = client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=2048,
            system=system_prompt,
            messages=conversation_history,
        )
        reply = response.content[0].text
        add_to_history("assistant", reply)
        return reply
    except Exception as e:
        log.error(f"Claude error: {e}")
        return f"Error reaching Claude: {e}"


# ─── WHISPER TRANSCRIPTION ────────────────────────────────────────────────────

async def transcribe_voice(file_id: str) -> str:
    if not OPENAI_API_KEY:
        return "[Voice note received but OPENAI_API_KEY not set for transcription]"

    async with httpx.AsyncClient() as client:
        # Get file path from Telegram
        r = await client.get(f"{TELEGRAM_API}/getFile", params={"file_id": file_id})
        file_path = r.json()["result"]["file_path"]

        # Download the OGG file
        audio_url = f"https://api.telegram.org/file/bot{TELEGRAM_BOT_TOKEN}/{file_path}"
        audio_r = await client.get(audio_url)
        audio_bytes = audio_r.content

        # Send to Whisper
        whisper_r = await client.post(
            "https://api.openai.com/v1/audio/transcriptions",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
            files={"file": ("voice.ogg", audio_bytes, "audio/ogg")},
            data={"model": "whisper-1"},
        )

        if whisper_r.status_code == 200:
            return whisper_r.json()["text"]
        else:
            log.error(f"Whisper error: {whisper_r.text}")
            return "[Transcription failed — voice note could not be processed]"


# ─── TELEGRAM HELPERS ─────────────────────────────────────────────────────────

async def send_message(chat_id: int, text: str, parse_mode: str = "Markdown"):
    """Send a message to a Telegram chat."""
    async with httpx.AsyncClient() as client:
        # Telegram has a 4096 char limit — split if needed
        chunks = [text[i:i+4000] for i in range(0, len(text), 4000)]
        for chunk in chunks:
            await client.post(f"{TELEGRAM_API}/sendMessage", json={
                "chat_id": chat_id,
                "text": chunk,
                "parse_mode": parse_mode,
            })


async def send_typing(chat_id: int):
    async with httpx.AsyncClient() as client:
        await client.post(f"{TELEGRAM_API}/sendChatAction", json={
            "chat_id": chat_id,
            "action": "typing",
        })


# ─── SCHEDULED TASKS ──────────────────────────────────────────────────────────

async def nightly_loop():
    """
    Runs at 2 AM. Reads today's daily note, identifies blockers,
    asks Claude to summarize wins and open items, updates patterns.
    """
    log.info("Running nightly self-improvement loop...")
    today_context = load_today_context()

    if not today_context.strip():
        log.info("No daily context to process tonight.")
        return

    prompt = f"""
NIGHTLY SELF-IMPROVEMENT LOOP — {datetime.date.today().isoformat()}

Here is today's operational log:
{today_context}

Please:
1. Identify any moments where the founder had to unblock you (what were they?)
2. For each blocker: propose how to prevent it permanently
3. Extract any lessons to add to patterns.md
4. Write a 3-line Telegram summary: Revenue today | Top win | Top open blocker

Format the patterns update as:
PATTERNS_UPDATE:
[your additions to patterns.md]

Format the Telegram summary as:
TELEGRAM_SUMMARY:
[3-line summary]
"""

    response = await ask_claude(prompt)

    # Parse and save patterns
    if "PATTERNS_UPDATE:" in response:
        patterns_section = response.split("PATTERNS_UPDATE:")[1]
        if "TELEGRAM_SUMMARY:" in patterns_section:
            patterns_section = patterns_section.split("TELEGRAM_SUMMARY:")[0]
        patterns_section = patterns_section.strip()
        if patterns_section:
            path = MEMORY_DIR / "tacit" / "patterns.md"
            with open(path, "a") as f:
                f.write(f"\n\n## {datetime.date.today().isoformat()}\n{patterns_section}")
            log.info("Patterns updated.")

    # Send Telegram summary
    if "TELEGRAM_SUMMARY:" in response:
        summary = response.split("TELEGRAM_SUMMARY:")[1].strip()
        await send_message(ALLOWED_USER_ID, f"🌙 *Nightly Loop Complete*\n\n{summary}")

    # Create tomorrow's daily note template
    tomorrow = datetime.date.today() + datetime.timedelta(days=1)
    tomorrow_path = MEMORY_DIR / "daily" / f"{tomorrow.isoformat()}.md"
    tomorrow_path.parent.mkdir(parents=True, exist_ok=True)
    tomorrow_path.write_text(f"""# Daily Note — {tomorrow.isoformat()}

## Open Tasks

## Revenue Today
- Stripe: $

## Blockers

## Decisions Made

## Queued for Founder Review
""")
    log.info("Tomorrow's daily note template created.")


async def morning_digest():
    """Runs at 8 AM. Sends a brief morning status via Telegram."""
    log.info("Running morning digest...")

    prompt = """
MORNING DIGEST — Generate a brief morning status message for Bernardo.

Check the today's context and any recent patterns. Report:
1. What's on the agenda today (any open tasks from yesterday?)
2. Revenue snapshot if available
3. One proactive suggestion for today

Keep it to 4-5 lines max. Start with "☀️ Good morning."
"""
    response = await ask_claude(prompt)
    await send_message(ALLOWED_USER_ID, response)


# ─── WEBHOOK HANDLER ──────────────────────────────────────────────────────────

async def process_update(update: dict):
    """Core logic: handle an incoming Telegram update."""
    message = update.get("message") or update.get("edited_message")
    if not message:
        return

    chat_id = message["chat"]["id"]
    user_id = message["from"]["id"]

    # Security: only respond to the allowed user
    if user_id != ALLOWED_USER_ID:
        log.warning(f"Rejected message from unauthorized user {user_id}")
        await send_message(chat_id, "Unauthorized.")
        return

    await send_typing(chat_id)

    # Handle voice note
    if "voice" in message:
        file_id = message["voice"]["file_id"]
        await send_message(chat_id, "🎤 Transcribing voice note...")
        transcript = await transcribe_voice(file_id)
        user_text = f"[Voice note transcription]: {transcript}"
        save_to_daily_note(f"**Voice note from founder:** {transcript}")
        log.info(f"Transcribed voice note: {transcript[:100]}...")

    # Handle text message
    elif "text" in message:
        user_text = message["text"]
        save_to_daily_note(f"**Founder:** {user_text}")

        # Handle /commands
        if user_text.startswith("/"):
            await handle_command(chat_id, user_text)
            return
    else:
        await send_message(chat_id, "I received your message but couldn't process the content type.")
        return

    # Send to Claude
    reply = await ask_claude(user_text)
    save_to_daily_note(f"**Agent:** {reply[:500]}...")
    await send_message(chat_id, reply)


async def handle_command(chat_id: int, command: str):
    """Handle slash commands."""
    cmd = command.split()[0].lower()

    if cmd == "/start":
        await send_message(chat_id,
            "👋 Agent online.\n\n"
            "Send me text or voice notes. I'll think, decide, and act.\n\n"
            "Commands:\n"
            "/status — current open tasks\n"
            "/memory — what I know right now\n"
            "/loop — run nightly loop now\n"
            "/clear — clear conversation history"
        )

    elif cmd == "/status":
        context = load_today_context()
        if context:
            reply = await ask_claude("Give me a quick status: what are the open tasks and current revenue situation based on today's context?")
            await send_message(chat_id, reply)
        else:
            await send_message(chat_id, "No activity logged today yet.")

    elif cmd == "/memory":
        summary = f"📂 *Memory Summary*\n\n"
        for folder in ["life", "daily", "tacit"]:
            path = MEMORY_DIR / folder
            if path.exists():
                files = list(path.glob("*.md"))
                summary += f"*{folder}/*: {len(files)} files\n"
        await send_message(chat_id, summary)

    elif cmd == "/loop":
        await send_message(chat_id, "🔄 Running nightly loop now...")
        await nightly_loop()

    elif cmd == "/clear":
        conversation_history.clear()
        await send_message(chat_id, "✅ Conversation history cleared.")

    else:
        await send_message(chat_id, f"Unknown command: {cmd}")


# ─── FASTAPI APP ──────────────────────────────────────────────────────────────

scheduler = AsyncIOScheduler()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start scheduler
    scheduler.add_job(nightly_loop,   "cron", hour=2,  minute=0, id="nightly_loop")
    scheduler.add_job(morning_digest, "cron", hour=8,  minute=0, id="morning_digest")
    scheduler.start()
    log.info("Scheduler started. Nightly loop: 2 AM | Morning digest: 8 AM")
    yield
    scheduler.shutdown()


app = FastAPI(title="Telegram Agent", lifespan=lifespan)


@app.get("/")
async def root():
    return {"status": "Agent online", "time": datetime.datetime.utcnow().isoformat()}


@app.post("/webhook")
async def webhook(request: Request, background_tasks: BackgroundTasks):
    # Verify secret if configured
    if TELEGRAM_WEBHOOK_SECRET:
        secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if secret != TELEGRAM_WEBHOOK_SECRET:
            raise HTTPException(status_code=403, detail="Invalid secret")

    update = await request.json()
    log.info(f"Update received: {json.dumps(update)[:200]}")

    # Process in background so Telegram doesn't time out
    background_tasks.add_task(process_update, update)
    return JSONResponse({"ok": True})


@app.get("/health")
async def health():
    return {"status": "ok", "memory_files": sum(1 for _ in MEMORY_DIR.rglob("*.md"))}


# ─── WEBHOOK REGISTRATION ─────────────────────────────────────────────────────

async def register_webhook(public_url: str):
    """Call this once to tell Telegram where to send updates."""
    async with httpx.AsyncClient() as client:
        url = f"{TELEGRAM_API}/setWebhook"
        payload = {
            "url": f"{public_url}/webhook",
            "allowed_updates": ["message", "edited_message"],
            "drop_pending_updates": True,
        }
        if TELEGRAM_WEBHOOK_SECRET:
            payload["secret_token"] = TELEGRAM_WEBHOOK_SECRET

        r = await client.post(url, json=payload)
        log.info(f"Webhook registration: {r.json()}")
        return r.json()


if __name__ == "__main__":
    import uvicorn
    # To register webhook: python main.py --register-webhook https://your-app.railway.app
    import sys
    if "--register-webhook" in sys.argv:
        idx = sys.argv.index("--register-webhook")
        public_url = sys.argv[idx + 1]
        asyncio.run(register_webhook(public_url))
    else:
        uvicorn.run("main:app", host="0.0.0.0", port=int(os.environ.get("PORT", 8000)), reload=False)
