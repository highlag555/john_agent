# Operational Patterns & Lessons

## Lessons Learned
(Updated nightly by the self-improvement loop)

## Known Failure Modes
(Add entries as they occur: describe the failure and the permanent fix)

## Recurring Decisions
(Log decisions made more than once — if it keeps coming up, automate it)
